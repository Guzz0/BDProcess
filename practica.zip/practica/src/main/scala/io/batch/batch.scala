package io.batch


import java.time.OffsetDateTime

import org.apache.spark.sql.{DataFrame, SparkSession}

trait batch {

  val spark: SparkSession

  def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame

  def readMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame



  def suma_antenna_bytes(dataFrame: DataFrame,metricName: String, filterDate: OffsetDateTime): DataFrame

  def suma_app_bytes(dataFrame: DataFrame,metricName: String, filterDate: OffsetDateTime): DataFrame

  def suma_user_bytes(dataFrame: DataFrame,metricName: String, filterDate: OffsetDateTime): DataFrame

  def mail_Exceed_Quota(dataFrame: DataFrame, userMetadataDF: DataFrame): DataFrame

  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit

}



package io.batch

import java.time.OffsetDateTime
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


object batchjob extends batch {
  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .appName("batch ")
    .getOrCreate()

  import spark.implicits._

  override def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame = {
    spark
      .read
      .format("parquet")
      .load(s"$storagePath/data")
      .filter(
        ($"year" === filterDate.getYear) &&
          ($"month" === filterDate.getMonthValue) &&
          ($"day" === filterDate.getDayOfMonth) &&
          ($"hour" === filterDate.getHour)
      )
  }


  override def readMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }


  override def suma_app_bytes(dataFrame: DataFrame, metricName: String,filterDate: OffsetDateTime): DataFrame = {
    dataFrame
      .select(cols =  $"app", $"bytes")
      .groupBy(cols = $"app".as("id"))
      .agg(sum($"bytes").as("value"))
      .withColumn("type", lit(metricName))
      .withColumn("timestamp", lit(filterDate.toEpochSecond).cast(TimestampType))

  }

   override def suma_user_bytes(dataFrame: DataFrame, metricName: String, filterDate: OffsetDateTime): DataFrame = {
      dataFrame
        .select(cols =  $"id", $"bytes")
        .groupBy(cols = $"id".as("id"))
        .agg(
          sum($"bytes").as("value")
        ).withColumn("type", lit(metricName))
        .withColumn("timestamp", lit(filterDate.toEpochSecond).cast(TimestampType))
   }

   override def suma_antenna_bytes(dataFrame: DataFrame,metricName: String, filterDate: OffsetDateTime): DataFrame = {
        dataFrame
          .select(cols =  $"antenna_id", $"bytes")
          .groupBy(cols = $"antenna_id".as("id"))
          .agg(
            sum($"bytes").as("value")
          ).withColumn("type", lit(metricName))
          .withColumn("timestamp", lit(filterDate.toEpochSecond).cast(TimestampType))
   }

  override def mail_Exceed_Quota(user_total_bytes: DataFrame, userMetadataDF: DataFrame): DataFrame = {
    user_total_bytes.as("user").select($"id", $"value", $"timestamp")
      .join(
        userMetadataDF.select($"id", $"email", $"quota").as("metadata"),
        $"user.id" === $"metadata.id" && $"user.value" > $"metadata.quota"
      )
      .select($"metadata.email" as "email", $"user.value".as("usage"), $"metadata.quota", $"user.timestamp")
  }


  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
      dataFrame
        .write
        .mode(SaveMode.Append)
        .format("jdbc")
        .option("driver", "org.postgresql.Driver")
        .option("url", jdbcURI)
        .option("dbtable", jdbcTable)
        .option("user", user)
        .option("password", password)
        .save()
    }

    override def writeToStorage(dataFrame: DataFrame, storagePath: String): Unit = {
      dataFrame
        .write
        .partitionBy("year", "month", "day", "hour")
        .format("parquet")
        .mode(SaveMode.Overwrite)
        .save(s"$storagePath/historical")
    }


    def main(args: Array[String]): Unit = {
      val jdbcUri = "jdbc:postgresql://34.91.216.129:5432/postgres"
      val jdbcUser = "postgres"
      val jdbcPassword = "apache"
      val offsetDateTime= OffsetDateTime.parse("2023-01-28T22:00:00Z")
      val parquetDF = readFromStorage("/tmp/project_devices",offsetDateTime)
      val metadataDF = readMetadata(jdbcUri, "user_metadata", jdbcUser, jdbcPassword)

      val antenna_Bytes = suma_antenna_bytes(parquetDF, "bytes_antenna", offsetDateTime )
      val users_Bytes = suma_user_bytes(parquetDF, "bytes_user",offsetDateTime).cache()
      val app_Bytes = suma_app_bytes(parquetDF, "bytes_app", offsetDateTime)
      val user_limit = mail_Exceed_Quota(users_Bytes, metadataDF)


      writeToJdbc(antenna_Bytes, jdbcUri, "bytes_hourly", jdbcUser, jdbcPassword)
      writeToJdbc(users_Bytes, jdbcUri, "bytes_hourly", jdbcUser, jdbcPassword)
      writeToJdbc(app_Bytes, jdbcUri, "bytes_hourly", jdbcUser, jdbcPassword)
      writeToJdbc(user_limit, jdbcUri, "user_quota_limit", jdbcUser, jdbcPassword)

      spark.close()
    }


}
package io.streaming

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Await, Future}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType, TimestampType}

import scala.concurrent.duration.Duration




object StreamingJob extends StreamJob {

  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[20]")
    .appName("Devices Streaming Job")
    .getOrCreate()

  import spark.implicits._

  override def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .option("failOnDataLoss","false")
      .load()
  }

  override def parserJsonData(dataFrame: DataFrame): DataFrame= {
    val jsonSchema = StructType(Seq(
      StructField("timestamp", TimestampType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("antenna_id", StringType, nullable = false),
      StructField("bytes", LongType, nullable = false),
      StructField("app", StringType, nullable = false)
    ))
    dataFrame
      .select(from_json(col("value").cast(StringType), jsonSchema).as("json"))
      .select("json.*")
  }

  override def writeToStorage(dataFrame: DataFrame, storagePath: String): Future[Unit] = Future {
    dataFrame
      .select(
        $"id", $"antenna_id", $"bytes", $"app",
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour"),
      )
      .writeStream
      .format("parquet")
      .option("path", s"$storagePath/data")
      .option("checkpointLocation", s"$storagePath/checkpoint")
      .partitionBy("year", "month", "day", "hour")
      .start
      .awaitTermination()
  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    dataFrame
      .writeStream
      .foreachBatch { (data: DataFrame, batchId: Long) =>
        data
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcURI)
          .option("dbtable", jdbcTable)
          .option("user", user)
          .option("password", password)
          .save()
      }
      .start()
      .awaitTermination()
  }
  override def suma_antennas_bytes(data: DataFrame): DataFrame = {
    import data.sparkSession.implicits._
    data
      .select($"timestamp",col("antenna_id"), $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "1 minutes")
      .groupBy(window(timeColumn = $"timestamp", windowDuration = "5 minutes"),col("antenna_id"))
      .agg(sum($"bytes").as("total_bytes"))
      .select($"window.start".cast(TimestampType).as("timestamp"), col("antenna_id").as("id"), $"total_bytes".as("value"), lit("total_Bytes_Antenna").as("type"))
  }

  override def suma_user_bytes(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp",col( "id"), $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "1 minutes")
      .groupBy(window(timeColumn = $"timestamp", windowDuration = "5 minutes"),col( "id"))
      .agg(sum($"bytes").as("total_bytes"))
      .select($"window.start".cast(TimestampType).as("timestamp"), col("id").as("id"), $"total_bytes".as("value"), lit("total_Bytes_Users").as("type"))
  }


  override def suma_app_bytes(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp",col( "app"), $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "1 minutes")
      .groupBy(window(timeColumn = $"timestamp", windowDuration = "5 minutes"),col("app"))
      .agg(sum($"bytes").as("total_bytes"))
      .select($"window.start".cast(TimestampType).as("timestamp"), col("app").as("id"), $"total_bytes".as("value"), lit("total_Bytes_app").as("type"))

  }




  def main(args: Array[String]): Unit = {
    val jdbcUri = "jdbc:postgresql://34.91.216.129:5432/postgres"
    val jdbcUser = "postgres"
    val jdbcPassword = "apache"
    val jdbcTable = "bytes"
    val kafkaServer = "34.125.157.149:9092"

    val kafkaDF = readFromKafka(kafkaServer, "devices")
    val parseDF = parserJsonData(kafkaDF)

    val storageFuture = writeToStorage(parseDF,  "/ttmpa/project_devices/")
    val antenna_Bytes = suma_antennas_bytes( parseDF)
    val users_Bytes = suma_user_bytes(parseDF)
    val app_Bytes = suma_app_bytes(parseDF)
    val jdbcantenna = writeToJdbc(antenna_Bytes, jdbcUri, jdbcTable, jdbcUser, jdbcPassword) //sql
    val jdbcuser = writeToJdbc(users_Bytes, jdbcUri, jdbcTable, jdbcUser, jdbcPassword)
    val jdbcapp = writeToJdbc(app_Bytes, jdbcUri, jdbcTable, jdbcUser, jdbcPassword)

    Await.result(
      Future.sequence(Seq(storageFuture, jdbcantenna,jdbcuser,jdbcapp)), Duration.Inf
    )

    spark.close()
  }
}
package io.streaming
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.concurrent.Future


trait StreamJob {

  val spark: SparkSession

  def readFromKafka(kafkaServer: String, topic: String): DataFrame

  def parserJsonData(dataFrame: DataFrame): DataFrame





  def suma_antennas_bytes(dataFrame: DataFrame): DataFrame

  def suma_app_bytes(dataFrame: DataFrame): DataFrame

  def suma_user_bytes(dataFrame: DataFrame): DataFrame
  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit]

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit]

}
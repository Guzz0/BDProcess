package io.provisioner

import java.sql.{Connection, DriverManager, Statement}

object JDBC {
  def main(args: Array[String]): Unit = {
    val ipServer = "localhost:9092"
    val url = "jdbc:postgresql://localhost:9092/postgres"
    val username = "postgres"
    val password = "apache"

    // Crear tablas si no existen
    val createBytesTableSql =
      """
        |CREATE TABLE IF NOT EXISTS bytes (
        |  timestamp TIMESTAMP,
        |  id TEXT,
        |  value BIGINT,
        |  type TEXT
        |)
      """.stripMargin
    val createBytesHourlyTableSql =
      """
        |CREATE TABLE IF NOT EXISTS bytes_hourly (
        |  timestamp TIMESTAMP,
        |  id TEXT,
        |  value BIGINT,
        |  type TEXT
        |)
      """.stripMargin
    val createUserMetadataTableSql =
      """
        |CREATE TABLE IF NOT EXISTS user_metadata (
        |  id TEXT,
        |  name TEXT,
        |  email TEXT,
        |  quota BIGINT
        |)
      """.stripMargin
    val createUserQuotaLimitTableSql =
      """
        |CREATE TABLE IF NOT EXISTS user_quota_limit (
        |  email TEXT,
        |  usage BIGINT,
        |  quota BIGINT,
        |  timestamp TIMESTMAP
        |)
      """.stripMargin



    // conectar con cloud sql postgre
    Class.forName("org.postgresql.Driver")
    val connection: Connection = DriverManager.getConnection(url, username, password)
    connection.setAutoCommit(false)


      val cargar: Statement = connection.createStatement
      println("Conexión establecida correctamente!")
      // Create tables
      cargar.executeUpdate(createBytesTableSql)
      cargar.executeUpdate(createBytesHourlyTableSql)
      cargar.executeUpdate(createUserMetadataTableSql)
      cargar.executeUpdate(createUserQuotaLimitTableSql)

      // Insert data into user_metadata table
      val insertUserMetadataSql =
        """
          |INSERT INTO user_metadata (id, name, email, quota)
          |VALUES (?, ?, ?, ?)
      """.stripMargin
      val insertUserMetadataPreparedStatement = connection.prepareStatement(insertUserMetadataSql)

      val user_metadata = Seq(
        ("00000000-0000-0000-0000-000000000001", "andres", "andres@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000002", "paco", "paco@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000003", "juan", "juan@gmail.com", 100000),
        ("00000000-0000-0000-0000-000000000004", "fede", "fede@gmail.com", 5000),
        ("00000000-0000-0000-0000-000000000005", "gorka", "gorka@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000006", "luis", "luis@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000007", "eric", "eric@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000008", "cristian", "cristian@gmail.com", 100000),
        ("00000000-0000-0000-0000-000000000009", "david", "david@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000010", "juanchu", "juanchu@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000011", "charo", "charo@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000012", "delicidas", "delicidas@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000013", "milagros", "milagros@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000014", "antonio", "antonio@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000015", "sergio", "sergio@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000016", "maria", "maria@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000017", "cristina", "cristina@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000018", "lucia", "lucia@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000019", "carlota", "carlota@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000020", "emilio", "emilio@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000009", "david", "david@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000010", "juanchu", "juanchu@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000011", "charo", "charo@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000012", "delicidas", "delicidas@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000013", "milagros", "milagros@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000014", "antonio", "antonio@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000015", "sergio", "sergio@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000016", "maria", "maria@gmail.com", 1000000),
        ("00000000-0000-0000-0000-000000000017", "cristina", "cristina@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000018", "lucia", "lucia@gmail.com", 300000),
        ("00000000-0000-0000-0000-000000000019", "carlota", "carlota@gmail.com", 200000),
        ("00000000-0000-0000-0000-000000000020", "emilio", "emilio@gmail.com", 200000)
      )

      for ((id, name, email, quota) <- user_metadata) {
        insertUserMetadataPreparedStatement.setString(1, id)
        insertUserMetadataPreparedStatement.setString(2, name)
        insertUserMetadataPreparedStatement.setString(3, email)
        insertUserMetadataPreparedStatement.setInt(4, quota)
        insertUserMetadataPreparedStatement.executeUpdate()


      }
      println("creando tablas y agregando datos a user_metadata... ")
      val selectUserMetadataSql = "SELECT * FROM user_metadata"
      val resultSet = cargar.executeQuery(selectUserMetadataSql)
      while (resultSet.next()) {
        val id = resultSet.getString("id")
        val name = resultSet.getString("name")
        val email = resultSet.getString("email")
        val quota = resultSet.getInt("quota")
        println(s"id: $id, name: $name, email: $email, quota: $quota")
      }

      connection.commit()
      connection.rollback()

    }

}
